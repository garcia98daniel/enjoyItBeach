<br/><div class='rechazado'>
		<label style='color:#FA206A'>
			<?php  echo $msj; ?>
		</label>  
	</div> 