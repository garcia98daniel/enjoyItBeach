<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class recharge extends Model
{
    //
}
