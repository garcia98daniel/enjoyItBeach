<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\sale;
use Faker\Generator as Faker;

$factory->define(sale::class, function (Faker $faker) {
    return [
        //
    ];
});
