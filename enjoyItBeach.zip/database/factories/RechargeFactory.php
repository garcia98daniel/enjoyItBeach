<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\recharge;
use Faker\Generator as Faker;

$factory->define(recharge::class, function (Faker $faker) {
    return [
        //
    ];
});
