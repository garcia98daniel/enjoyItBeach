<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\reservation;
use Faker\Generator as Faker;

$factory->define(reservation::class, function (Faker $faker) {
    return [
        //
    ];
});
