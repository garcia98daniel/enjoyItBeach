    <style>
      .img-container{
        height: 150px;
        margin: 5px;
        border-radius: 5px;
      }

      .restaurant-container{
        cursor: pointer;
        padding: 0 !important;
      }

      .restaurant-container:hover{
        transform: scale(0.98);
      }
    </style>

    <div class="box-header">
      <h3 class="box-title">Restaurantes</h3>
    </div><!-- /.box-header -->
    <?php if(count($restaurantes)>0): ?>
      <div id="notificacion_resul_fanu"></div> 
      <?php $__currentLoopData = $restaurantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="box box-primary col-xs-12 restaurant-container " onclick="cargarformulario('comidas/'+<?php echo e($restaurante->id); ?>);">
          <div class="container-fluid">
            <div class="row">
             <div class="img-container col-xs-4 col-md-2 bg-primary">
               <img src="" alt="resturante_img">
             </div>
             <div class="info-restaurant col-xs-7 col-md-9">
                   <div class="row">
                      <div class="col">
                         <h2><?php echo e($restaurante->nombre); ?></h2>
                      </div>
                   </div>
                   <div class="row">
                     <div class="col">
                       <h5><strong>Reputacion</strong></h5> 
                     </div>
                   </div>
                   <div class="row">
                     <div class="col">
                       <h6>Duracion del pedido</h6> 
                     </div>
                   </div>
              </div>
            </div>
          </div>
     </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
      <h2>Lo sentimos, No hay restaurantes disponibles en el momento</h2>
    <?php endif; ?>  

<?php /**PATH C:\Users\DELL\Desktop\misProyectos\enjoyItBeach\resources\views/formularios/listaRestaurantes.blade.php ENDPATH**/ ?>